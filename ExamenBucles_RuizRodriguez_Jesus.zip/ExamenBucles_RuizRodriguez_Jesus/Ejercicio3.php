<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
   
</head>
<body>
    <form action="Formulario3.php" method="post">

    <input type="number" name="numero">
    <input type="submit" value="Enviar">
    </form>
    
</body>
</html>