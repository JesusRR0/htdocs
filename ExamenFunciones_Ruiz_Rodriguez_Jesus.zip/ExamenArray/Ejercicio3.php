<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php 
    $numero =$_POST['numero'];
    $array = [$numero]; 

    

    separarDigitos($array);
?>

    <form action="#" method="post">
        <input type="text" name="numero">
        <input type="submit" value="OK">

    </form>
<?php 

    function separarDigitos($arrayAux){

       foreach($arrayAux as $clave => $valor){
           echo "pòsicion =>".$clave." valor => ".$valor;
       }

    }



?>    
</body>
</html>